# Daily Journal 📝

A simple personal note-taking web app built using HTML, CSS, and JavaScript.  
Perfect for keeping track of your daily thoughts or tasks.

## Features
- Create and save journal entries
- Clean and responsive design
- Easy to use interface

## Tech Stack
- HTML
- CSS
- JavaScript

## How to Use
1. Clone the repo
2. Open `index.html` in your browser
