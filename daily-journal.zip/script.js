document.getElementById('entryForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const content = document.getElementById('content').value;

    const entry = document.createElement('div');
    entry.className = 'entry';
    entry.innerHTML = `<h2>${title}</h2><p>${content}</p>`;

    document.getElementById('entries').prepend(entry);

    this.reset();
});
